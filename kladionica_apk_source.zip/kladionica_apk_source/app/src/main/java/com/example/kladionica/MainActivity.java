package com.example.kladionica;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String CHANNEL_ID = "sigma_jokes";
    private static final int NOTIFICATION_REQUEST = 77;
    private TextView status;
    private boolean notificationRequested = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showScreen();
        createNotificationChannel();
    }

    private int dp(float value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private Button button(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setAllCaps(false);
        b.setTextSize(15);
        return b;
    }

    private void showScreen() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER);
        page.setPadding(dp(24), dp(30), dp(24), dp(24));
        page.setBackgroundColor(Color.rgb(9, 9, 9));

        TextView eyebrow = text("UNKNOWN APPLICATION · SAFE PRANK", 12, Color.rgb(255, 69, 69));
        page.addView(eyebrow, new LinearLayout.LayoutParams(-1, -2));

        TextView title = text("KLADIONICA.EXE", 30, Color.WHITE);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        title.setPadding(0, dp(18), 0, dp(8));
        page.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = text("Zvanična sigma kladionica.\nVerovatno. Možda. Ko zna.", 16, Color.LTGRAY);
        page.addView(subtitle, new LinearLayout.LayoutParams(-1, -2));

        status = text("● STATUS: ČEKA SE SIGMA", 13, Color.rgb(255, 119, 119));
        status.setPadding(dp(10), dp(18), dp(10), dp(18));
        page.addView(status, new LinearLayout.LayoutParams(-1, -2));

        Button run = button("Pokreni sigma proveru");
        page.addView(run, new LinearLayout.LayoutParams(-1, -2));
        run.setOnClickListener(v -> {
            status.setText("STATUS: 100% SIGMA DETEKTOVANA");
            new android.app.AlertDialog.Builder(this)
                .setTitle("KLADIONICA.EXE")
                .setMessage("sve tvoje pare su postale sigme i otisle u sigma kladionicu")
                .setPositiveButton("OK, SIGMA", (d, w) -> d.dismiss())
                .show();
        });

        Button notify = button("Zatraži dozvolu za obaveštenja");
        LinearLayout.LayoutParams notifyParams = new LinearLayout.LayoutParams(-1, -2);
        notifyParams.topMargin = dp(8);
        page.addView(notify, notifyParams);
        notify.setOnClickListener(v -> requestNotification());

        TextView note = text("Bez uplata. Bez naloga. Bez prikupljanja podataka.\nOvo je samo šala.", 12, Color.GRAY);
        LinearLayout.LayoutParams noteParams = new LinearLayout.LayoutParams(-1, -2);
        noteParams.topMargin = dp(16);
        page.addView(note, noteParams);

        TextView footer = text("PROTOTIP 0.3 · SIGMA MODE", 11, Color.DKGRAY);
        LinearLayout.LayoutParams footerParams = new LinearLayout.LayoutParams(-1, -2);
        footerParams.topMargin = dp(20);
        page.addView(footer, footerParams);

        setContentView(page);
    }

    private void requestNotification() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationRequested = true;
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_REQUEST);
        } else {
            sendJokeNotification();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == NOTIFICATION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendJokeNotification();
            } else if (status != null) {
                status.setText("STATUS: DOZVOLA NIJE DATA");
            }
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "Sigma joke notifications", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("One harmless joke notification requested by the user.");
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    private void sendJokeNotification() {
        NotificationManager manager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= 26) {
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
        }
        builder.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("KLADIONICA.EXE")
            .setContentText("sve tvoje pare su postale sigme i otisle u sigma kladionicu")
            .setStyle(new Notification.BigTextStyle().bigText(
                "sve tvoje pare su postale sigme i otisle u sigma kladionicu"))
            .setAutoCancel(true);
        manager.notify(1001, builder.build());
        if (status != null) status.setText("STATUS: SIGMA OBAVEŠTENJE POSLATO");
    }
}
